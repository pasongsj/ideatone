from tkinter import *

root = Tk()
root.title("Particulate Mask")
root.geometry("500x770")

mainimg = PhotoImage(file="main.gif")
menuimg = PhotoImage(file="menu.gif")
menubarimg = PhotoImage(file="menubar.gif")
shopimg = PhotoImage(file="shopping.gif")
shopinimg = PhotoImage(file="shopin.gif")
shopexitimg = PhotoImage(file="shopexit.gif")
loadingimg = PhotoImage(file="loading.gif")
timerstartimg = PhotoImage(file="timer_start.gif")

class Time():
    def __init__(self, sec=0, min=0, hour=0, count=0):
        self.sec = sec
        self.min = min
        self.hour = hour
        self.count = count

    def time_calculate(self):
        self.sec += 1

        if(self.sec == 60):
            self.sec -= 60
            self.min += 1

            if(self.min == 60):
                self.min -= 60
                self.hour += 1

        self.count += 1

    def count(self):
        self.count += 1

    def return_time(self):
        if self.hour >= 10:
            if self.min >= 10 and self.sec >= 10:
                time_str = "                " +str(self.hour) + ":" + str(self.min) + ":" + str(self.sec)
                return time_str

            elif self.min >= 10 and self.sec < 10:
                time_str = "                " +str(self.hour) + ":" + str(self.min) + ":0" + str(self.sec)
                return time_str

            elif self.min < 10 and self.sec >= 10:
                time_str = "                " +str(self.hour) + ":0" + str(self.min) + ":" + str(self.sec)
                return time_str

            else:
                time_str = "                " + str(self.hour) + ":0" + str(self.min) + ":0" + str(self.sec)
                return time_str

        else:
            if self.min >= 10 and self.sec >= 10:
                time_str = "               0" + str(self.hour) + ":" + str(self.min) + ":" + str(self.sec)
                return time_str

            elif self.min >= 10 and self.sec < 10:
                time_str = "               0" + str(self.hour) + ":" + str(self.min) + ":0" + str(self.sec)
                return time_str

            elif self.min < 10 and self.sec >= 10:
                time_str = "               0" + str(self.hour) + ":0" + str(self.min) + ":" + str(self.sec)
                return time_str

            else:
                time_str = "               0" + str(self.hour) + ":0" + str(self.min) + ":0" + str(self.sec)
                return time_str

    def return_count(self):
        return self.count

class Percent():
    def __init__(self, pc=0):
        self.pc = pc

    def pc_calculate(self, c):
        if c % 10 == 0:
            self.pc += 1

    def return_pc(self):
        if self.pc >= 10:
            return str(self.pc)
        else:
            return "0" + str(self.pc)


def main():
    time_go = Time()
    mask_per = Percent()

    def main_screen():
        mainimage = Label(image=mainimg)
        mainimage.grid(row=0, column=0)

        menu_formain = Button(image=menubarimg, command=lambda: menu())
        menu_formain.place(x=12, y=12)

        mask_timer = Entry(root, width=20, font=("궁서", 20))
        mask_timer.place(x=120, y=55)

        mask_percent = Entry(root, width=3, font=("궁서", 20))
        mask_percent.place(x=165, y=93)

        time_now = time_go.return_time()
        mask_timer.insert(0, time_now)

        mask_now = mask_per.return_pc()
        mask_percent.insert(0, mask_now)

        def time_show():
            time_now = time_go.return_time()
            mask_timer.delete(0, END)
            mask_timer.insert(0, str(time_now))
            root.after(1000, time_show)
        root.after(1000, time_show)

        def mask_percent_show():
            mask_now = mask_per.return_pc()
            mask_percent.delete(0, END)
            mask_percent.insert(0, str(mask_now))
            root.after(1000, mask_percent_show)
        root.after(1000, mask_percent_show)

        def mask_time():
            time_go.time_calculate()
            time_now = time_go.return_time()
            temp_count = time_go.return_count()
            mask_per.pc_calculate(temp_count)
            mask_now = mask_per.return_pc()
            mask_timer.delete(0, END)
            mask_timer.insert(0, str(time_now))
            mask_percent.delete(0, END)
            mask_percent.insert(0, str(mask_now))
            root.after(1000, mask_time)

        timer_start = Button(image=timerstartimg, command=lambda: mask_time())
        timer_start.place(x=30, y=215)

    def menu():
        menuimage = Label(image=menuimg)
        menuimage.grid(row=0, column=0)

        menu_tomain = Button(image=menubarimg, command=lambda: main_screen())
        menu_tomain.place(x=380, y=15)

        menu_toshop = Button(image=shopinimg, command=lambda: shopping())
        menu_toshop.place(x=19, y=305)

    def shopping():
        shopimage = Label(image=shopimg)
        shopimage.grid(row=0, column=0)

        shop_exit = Button(image=shopexitimg, command=lambda: main_screen())
        shop_exit.place(x=5, y=5)

    main_screen()
    root.mainloop()

loading = Label(image=loadingimg)
loading.grid(row=0, column=0)
root.after(3000, main)

root.mainloop()